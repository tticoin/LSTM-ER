#ifndef CNN_EIGEN_RANDOM_H
#define CNN_EIGEN_RANDOM_H

#include <random>

namespace cnn {

extern std::mt19937* rndeng;

} // namespace cnn

#endif
