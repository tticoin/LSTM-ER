#include "cnn/training.h"
#include "cnn/cnn.h"
#include "cnn/gpu-ops.h"

namespace cnn {

using namespace std;

Trainer::~Trainer() {}

float Trainer::clip_gradients() {
  float gscale = 1;
  if (clipping_enabled) {
    float gg = model->gradient_l2_norm();
    if (gg > clip_threshold) {
      ++clips;
      gscale = clip_threshold / gg;
    }
  }
  return gscale;
}

void SimpleSGDTrainer::update(real scale) {
    update(model->lookup_parameters_list(), model->parameters_list(), scale);
}

void SimpleSGDTrainer::update(const std::vector<LookupParameters*> &lookup_params, const std::vector<Parameters*> &params, real scale) {
  const float gscale = clip_gradients();
  for (auto p : params) {
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
#if HAVE_CUDA
    gpu::sgd_update(p->values.d.size(), p->g.v, p->values.v, eta * scale * gscale, tlambda);
#else
    auto reg = (*p->values) * tlambda;
    *p->values -= ((eta * scale * gscale) * *p->g + reg);
#endif
    p->clear();
  }
  for (auto p : lookup_params) {
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    for (auto i : p->non_zero_grads) {
#if HAVE_CUDA
      gpu::sgd_update(p->values[i].d.size(), p->grads[i].v, p->values[i].v, eta * scale * gscale, tlambda);
#else
      auto reg = (*p->values[i]) * tlambda;
      *p->values[i] -= (*p->grads[i] * (eta * scale * gscale) + reg);
#endif
    }
    p->clear();
  }
  ++updates;
}

void MomentumSGDTrainer::update(real scale) {
  // executed on the first iteration to create vectors to
  // store the velocity
  if (!velocity_allocated) {
    vp = AllocateShadowParameters(*model);
    vlp = AllocateShadowLookupParameters(*model);
    velocity_allocated = true;
  }

  const float gscale = clip_gradients();
  unsigned pi = 0;
  for (auto p : model->parameters_list()) {
    Tensor& v = vp[pi++].h;
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    auto reg = *p->values * tlambda;
    (*v) = momentum * (*v) - (eta * scale * gscale) * (*p->g);
    *p->values += *v - reg;
    p->clear();
  }
  pi = 0;
  for (auto p : model->lookup_parameters_list()) {
    vector<Tensor>& vx = vlp[pi++].h;
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    for (auto i : p->non_zero_grads) {
      Tensor& v = vx[i];
      auto reg = (*p->values[i]) * tlambda;
      (*v) = momentum * (*v) - (eta * scale * gscale) * (*p->grads[i]);
      *p->values[i] += *v - reg;
    }
    p->clear();
  }
  ++updates;
}

void AdagradTrainer::update(real scale) {
  unsigned pi;
  if (!shadow_params_allocated) {
    vp = AllocateShadowParameters(*model);
    vlp = AllocateShadowLookupParameters(*model);
    shadow_params_allocated = true;
  }

  pi = 0;
  const float gscale = clip_gradients();
  for (auto p : model->parameters_list()) {
    Tensor& v = vp[pi++].h;
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    auto reg = (*p->values) * tlambda;
    auto& g = (scale * gscale) * *p->g;
    auto g2 = g.cwiseProduct(g);
    (*v) += g2;
    auto delta = - eta * g.cwiseQuotient(((*v).array() + epsilon).matrix().cwiseSqrt());
    *p->values += delta - reg;
    p->clear();
  }

  pi = 0;
  for (auto p : model->lookup_parameters_list()) {
    vector<Tensor>& vx = vlp[pi++].h;
    for (auto i : p->non_zero_grads) {
      Tensor& v = vx[i];
      auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
      auto reg = (*p->values[i]) * tlambda;
      auto& g = (scale * gscale) * *p->grads[i];
      auto g2 = g.cwiseProduct(g);
      (*v) += g2;
      auto delta = - eta * g.cwiseQuotient(((*v).array() + epsilon).matrix().cwiseSqrt());
      *p->values[i] += delta - reg;
    }
    p->clear();
  }

  ++updates;
}

void AdadeltaTrainer::update(real scale) {
  unsigned pi;
  if (!shadow_params_allocated) {
    hg = AllocateShadowParameters(*model);
    hlg = AllocateShadowLookupParameters(*model);
    hd = AllocateShadowParameters(*model);
    hld = AllocateShadowLookupParameters(*model);

    /*pi = 0;
    for (auto p : model->parameters_list()) {
      TensorTools::Constant(hg[pi].h, epsilon);
      TensorTools::Constant(hd[pi].h, epsilon);
      ++pi;
    }

    pi = 0;
    for (auto p : model->lookup_parameters_list()) {
      vector<Tensor>& hgx = hlg[pi].h;
      vector<Tensor>& hdx = hld[pi].h;
      for (unsigned i = 0; i < hgx.size(); ++i) {
        TensorTools::Constant(hgx[i], epsilon);
        TensorTools::Constant(hdx[i], epsilon);
      }
      ++pi;
    }*/

    shadow_params_allocated = true;
  }

  const float gscale = clip_gradients();
  pi = 0;
  for (auto p : model->parameters_list()) {
    auto& g = (scale * gscale) * *p->g;
    Tensor& hgv = hg[pi].h;
    Tensor& hdv = hd[pi].h;
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    auto reg = (*p->values) * tlambda;
    auto g2 = g.cwiseProduct(g);
    *hgv = rho * *hgv + (1.0 - rho) * g2;
    auto num = -g.cwiseProduct(((*hdv).array() + epsilon).matrix().cwiseSqrt());
    auto den = ((*hgv).array() + epsilon).matrix().cwiseSqrt();
    auto delta = num.cwiseQuotient(den);
    auto d2 = delta.cwiseProduct(delta);
    *hdv = rho * *hdv + (1.0 - rho) * d2;
    *p->values += delta - reg;
    p->clear();
    pi++;
  }

  pi = 0;
  for (auto p : model->lookup_parameters_list()) {
    vector<Tensor>& hgvx = hlg[pi].h;
    vector<Tensor>& hdvx = hld[pi].h;
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    for (auto i : p->non_zero_grads) {
      Tensor& hgv = hgvx[i];
      Tensor& hdv = hdvx[i];
      auto& g = scale * gscale * *p->grads[i];
      auto reg = (*p->values[i]) * tlambda;
      auto g2 = g.cwiseProduct(g);
      *hgv = rho * *hgv + (1.0 - rho) * g2;
      auto num = -g.cwiseProduct(((*hdv).array() + epsilon).matrix().cwiseSqrt());
      auto den = ((*hgv).array() + epsilon).matrix().cwiseSqrt();
      auto delta = num.cwiseQuotient(den);
      auto d2 = delta.cwiseProduct(delta);
      *hdv = rho * *hdv + (1.0 - rho) * d2;
      *p->values[i] += delta - reg;
    }
    p->clear();
    pi++;
  }
  ++updates;
}

void RmsPropTrainer::update(real scale) {
  unsigned pi = 0;
  if (!shadow_params_allocated) {
    hg.resize(model->parameters_list().size());

    pi = 0;
    hlg.resize(model->lookup_parameters_list().size());
    for (auto p : model->lookup_parameters_list()) {
      hlg[pi++].resize(p->size());
    }

    shadow_params_allocated = true;
  }

  const float gscale = clip_gradients();
  pi = 0;
  for (auto p : model->parameters_list()) {
    auto& g = (scale * gscale) * *p->g;
    real& d2 = hg[pi++];
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    auto reg = (*p->values) * tlambda;
    real g2 = g.squaredNorm();
    d2 = rho * d2 + (1.0 - rho) * g2;
    *p->values -= ((eta / sqrt(d2 + epsilon)) * g + reg);
    p->clear();
  }

  pi = 0;
  for (auto p : model->lookup_parameters_list()) {
    vector<real>& hlgx = hlg[pi++];
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    for (auto i : p->non_zero_grads) {
      real& d2 = hlgx[i];
      auto reg = (*p->values[i]) * tlambda;
      auto& g = (scale * gscale) * *p->grads[i];
      real g2 = g.squaredNorm();
      d2 = rho * d2 + (1.0 - rho) * g2;
      *p->values[i] -= ((eta / sqrt(d2 + epsilon)) * g + reg);
    }
    p->clear();
  }
  ++updates;
}

void AdamTrainer::update(real scale) {
  unsigned pi;
  if (!shadow_params_allocated) {
    m = AllocateShadowParameters(*model);
    lm = AllocateShadowLookupParameters(*model);
    v = AllocateShadowParameters(*model);
    lv = AllocateShadowLookupParameters(*model);
    shadow_params_allocated = true;
    for (auto p : model->parameters_list()) {
      p->t = 0;
    }
    for (auto p : model->lookup_parameters_list()) {
      for (unsigned i = 0; i < p->t.size(); ++i){
        p->t[i] = 0;
      }
    }
  }

  const float gscale = clip_gradients();
  pi = 0;
  for (auto p : model->parameters_list()) {
    if(p->t == 0){
      if(cnn_average == 1){
        *p->sums = *p->values;
      }else if(cnn_average == 2){
        *p->sums = (1 - beta_2) * *p->values;
      }
    }
    p->t++;
    auto g_t = (scale * gscale) * *p->g;
    auto m_t = *m[pi].h;
    auto v_t = *v[pi].h;
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    auto reg = (*p->values) * tlambda;
    m_t = beta_1 * m_t + (1. - beta_1) * g_t;
    auto g2 = g_t.cwiseProduct(g_t);
    v_t = beta_2 * v_t + (1 - beta_2) * g2;
    float s1 = 1 - pow(beta_1, p->t);
    float s2 = 1 - pow(beta_2, p->t);
    auto mhat = m_t / s1;
    auto vhat = v_t / s2;
    auto delta = (-eta * mhat).cwiseQuotient((vhat.array().sqrt() + eps).matrix());
    *p->values += delta - reg;
    if(cnn_average == 1){
      *p->sums += *p->values;
    }else if(cnn_average == 2){
      *p->sums = beta_2 * *p->sums + (1 - beta_2) * *p->values;
    }
    p->clear();
    pi++;
  }

  pi = 0;
  for (auto p : model->lookup_parameters_list()) {
    vector<Tensor>& vm = lm[pi].h;
    vector<Tensor>& vv = lv[pi].h;
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    for (auto i : p->non_zero_grads) {
      if(p->t[i] == 0){
        if(cnn_average == 1){
          *p->sums[i] = *p->values[i];
        }else if(cnn_average == 2){
          *p->sums[i] = (1 - beta_2) * *p->values[i];
        }
      }
      p->t[i]++;
      auto m_t = *vm[i];
      auto v_t = *vv[i];
      auto g_t = scale * gscale * *p->grads[i];
      auto g2 = g_t.cwiseProduct(g_t);
      auto reg = *p->values[i] * tlambda;
      m_t = beta_1 * m_t + (1 - beta_1) * g_t;
      v_t = beta_2 * v_t + (1 - beta_2) * g2;
      float s1 = 1 - pow(beta_1, p->t[i]);
      float s2 = 1 - pow(beta_2, p->t[i]);
      auto mhat = m_t / s1;
      auto vhat = v_t / s2;
      auto delta = (-eta * mhat).cwiseQuotient((vhat.array().sqrt() + eps).matrix());
      *p->values[i] += delta - reg;
      if(cnn_average == 1){
        *p->sums[i] += *p->values[i];
      }else if(cnn_average == 2){
        *p->sums[i] = beta_2 * *p->sums[i] + (1 - beta_2) * *p->values[i];
      }      
    }
    p->clear();
    pi++;
  }
  ++updates;
}

void AdaMaxTrainer::update(real scale) {
  unsigned pi;
  if (!shadow_params_allocated) {
    m = AllocateShadowParameters(*model);
    lm = AllocateShadowLookupParameters(*model);
    v = AllocateShadowParameters(*model);
    lv = AllocateShadowLookupParameters(*model);
    shadow_params_allocated = true;
  }

  const float gscale = clip_gradients();
  pi = 0;
  for (auto p : model->parameters_list()) {
    if(p->t == 0){
      if(cnn_average == 1){
        *p->sums = *p->values;
      }else if(cnn_average == 2){
        *p->sums = (1 - beta_2) * *p->values;
      }
    }
    p->t++;
    auto g_t = (scale * gscale) * *p->g;
    auto m_t = *m[pi].h;
    auto& v_t = v[pi].h.v[0];
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    auto reg = (*p->values) * tlambda;
    m_t = beta_1 * m_t + (1. - beta_1) * g_t;
    v_t = max(beta_2 * v_t, g_t.norm() + eps);
    double s1 = 1 - pow(beta_1, p->t);
    auto delta = -(eta / s1 / v_t) * m_t;
    *p->values += delta - reg;
    if(cnn_average == 1){
      *p->sums += *p->values;
    }else if(cnn_average == 2){
      *p->sums = beta_2 * *p->sums + (1 - beta_2) * *p->values;
    }
    p->clear();
    pi++;
  }

  pi = 0;
  for (auto p : model->lookup_parameters_list()) {
    vector<Tensor>& vm = lm[pi].h;
    vector<Tensor>& vv = lv[pi].h;
    auto tlambda = p->lambda >= 0. ? p->lambda : lambda;
    for (auto i : p->non_zero_grads) {
      if(p->t[i] == 0){
        if(cnn_average == 1){
          *p->sums[i] = *p->values[i];
        }else if(cnn_average == 2){
          *p->sums[i] = (1 - beta_2) * *p->values[i];
        }
      }
      p->t[i]++;
      auto g_t = scale * gscale * *p->grads[i];
      auto m_t = *vm[i];
      auto& v_t = vv[i].v[0];
      auto reg = *p->values[i] * tlambda;
      m_t = beta_1 * m_t + (1 - beta_1) * g_t;
      v_t = max(beta_2 * v_t, g_t.norm() + eps);
      double s1 = 1 - pow(beta_1, p->t[i]);
      auto delta = - (eta / s1 / v_t) * m_t;
      *p->values[i] += delta - reg;
      if(cnn_average == 1){
        *p->sums[i] += *p->values[i];
      }else if(cnn_average == 2){
        *p->sums[i] = beta_2 * *p->sums[i] + (1 - beta_2) * *p->values[i];
      }
    }
    p->clear();
    pi++;
  }
  ++updates;
}


} // namespace cnn
